<h2 class="content-header-title float-left mb-0">Shop</h2>
<div class="breadcrumb-wrapper">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="index.html">Home</a>
        </li>
        <li class="breadcrumb-item"><a href="#">eCommerce</a>
        </li>
        <li class="breadcrumb-item active">Shop
        </li>
    </ol>
</div>  