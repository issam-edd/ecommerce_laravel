        <!-- BEGIN: Vendor JS-->
    <script src="<?php echo e(asset('app-assets/vendors/js/vendors.min.js')); ?>"></script>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <script src="<?php echo e(asset('app-assets/vendors/js/ui/jquery.sticky.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/vendors/js/extensions/wNumb.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/vendors/js/extensions/nouislider.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/vendors/js/extensions/toastr.min.js')); ?>"></script>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="<?php echo e(asset('app-assets/js/core/app-menu.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/js/core/app.js')); ?>"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <script src="<?php echo e(asset('app-assets/js/scripts/pages/app-ecommerce.js')); ?>"></script>
    <!-- END: Page JS-->

    <!-- OTHER: script-->
    <?php echo $__env->yieldContent('script'); ?>
    <!-- END OTHER: script -->

    <script>
        $(window).on('load', function() {
            if (feather) {
                feather.replace({
                    width: 14,
                    height: 14
                });
            }
        })
    </script><?php /**PATH C:\xampp\htdocs\ecommerce-website\resources\views/layouts/Interface/_scripts.blade.php ENDPATH**/ ?>