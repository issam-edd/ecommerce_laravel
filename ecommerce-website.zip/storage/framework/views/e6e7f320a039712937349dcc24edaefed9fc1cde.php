<?php if($errors->any()): ?>
    <div class="alert alert-danger p-1">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($error); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong><?php echo e(session('success')); ?></strong>
        <button type="button" class="close" data-dismiss="alert">
            <span>&times;</span>
        </button>
    </div>
<?php elseif(session('errorLink')): ?>
  <div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong><?php echo session('errorLink'); ?></strong>
    <button type="button" class="close" data-dismiss="alert">
        <span>&times;</span>
    </button>
  </div>
<?php elseif(session('info')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong><?php echo e(session('info')); ?></strong>
        <button type="button" class="close" data-dismiss="alert">
            <span>&times;</span>
        </button>
      </div>
<?php endif; ?>


<?php /**PATH C:\xampp\htdocs\ecommerce-website\resources\views/layouts/partials/alerts.blade.php ENDPATH**/ ?>