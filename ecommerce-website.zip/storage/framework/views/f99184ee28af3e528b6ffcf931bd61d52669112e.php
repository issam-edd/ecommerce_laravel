

<?php $__env->startSection('breadcrumbs'); ?>
<h2 class="content-header-title float-left mb-0">Product Details</h2>
<div class="breadcrumb-wrapper">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a>
        </li>
        <li class="breadcrumb-item active">Details
        </li>
    </ol>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <!-- app e-commerce details start -->
    <section class="app-ecommerce-details">
        <div class="card">
            <!-- Product Details starts -->
            <div class="card-body">
                <div class="row my-2">
                    <div class="col-12 col-md-5 d-flex align-items-center justify-content-center mb-2 mb-md-0">
                        <div class="d-flex align-items-center justify-content-center">
                            <img src=" <?php echo e($product->image??null); ?> " class="img-fluid product-img" alt="product image" />
                        </div>
                    </div>
                    <div class="col-12 col-md-7">
                        <h4><?php echo e($product->title); ?></h4>
                        <div class="ecommerce-details-price d-flex flex-wrap mt-1">
                            <h4 class="item-price mr-1"><?php echo e($product->price); ?> DH</h4>
                            <div class="item-price text-danger">
                                <strike><?php echo e($product->old_price); ?> DH</strike>
                            </div>
                        </div>
                        <?php if($product->inStock > 0): ?>
                        <p class="card-text">Available - <span class="text-success">In stock</span></p>
                        <?php else: ?>
                        <p class="card-text"> Not Available - <span class="text-danger"> Out of stock </span></p>
                        <?php endif; ?>
                        <p class="card-text">
                            <?php echo e($product->description); ?>

                        </p>
                        <ul class="product-features list-unstyled">
                            <li><i data-feather="shopping-cart"></i> <span>Free Shipping</span></li>
                        </ul>
                        <hr />
                        <form action="<?php echo e(route('add.cart',$product->slug)); ?> " method="get">
                            <?php echo method_field('GET'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="item-quantity">
                                <strong class="quantity-title">Qty:</strong>
                                <div class="input-group quantity-counter-wrapper">
                                  <input type="text" class="quantity-counter" name="quantity" value="1" />
                                </div>
                            </div>
                            <hr />
                            <div class="d-flex flex-column flex-sm-row pt-1">
                                <button type="submit" class="btn btn-primary btn-cart mr-0 mr-sm-1 mb-1 mb-sm-0">
                                    
                                    
                                    <span class="btn btn-primary">Add to cart</span>
                                </button>
                                
                                
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- Product Details ends -->

            <!-- Item features starts -->
            <div class="item-features">
                <div class="row text-center">
                    <div class="col-12 col-md-4 mb-4 mb-md-0">
                        <div class="w-75 mx-auto">
                            <i data-feather="award"></i>
                            <h4 class="mt-2 mb-1">100% Original</h4>
                            <p class="card-text">Chocolate bar candy canes ice cream toffee. Croissant pie cookie halvah.</p>
                        </div>
                    </div>
                    <div class="col-12 col-md-4 mb-4 mb-md-0">
                        <div class="w-75 mx-auto">
                            <i data-feather="clock"></i>
                            <h4 class="mt-2 mb-1">10 Day Replacement</h4>
                            <p class="card-text">Marshmallow biscuit donut dragée fruitcake. Jujubes wafer cupcake.</p>
                        </div>
                    </div>
                    <div class="col-12 col-md-4 mb-4 mb-md-0">
                        <div class="w-75 mx-auto">
                            <i data-feather="shield"></i>
                            <h4 class="mt-2 mb-1">1 Year Warranty</h4>
                            <p class="card-text">Cotton candy gingerbread cake I love sugar plum I love sweet croissant.</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Item features ends -->

            <!-- Related Products starts -->
            
            <!-- Related Products ends -->
        </div>
    </section>
    <!-- app e-commerce details end -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/vendors/css/forms/spinner/jquery.bootstrap-touchspin.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/vendors/css/extensions/swiper.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/css/pages/app-ecommerce-details.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/css/plugins/forms/form-number-input.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/css/plugins/forms/form-number-input.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('app-assets/vendors/js/extensions/swiper.min.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/js/scripts/pages/app-ecommerce-details.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/js/scripts/forms/form-number-input.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/js/scripts/pages/app-ecommerce-checkout.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.InterfaceCenter.appCenter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce-website\resources\views/products/show.blade.php ENDPATH**/ ?>