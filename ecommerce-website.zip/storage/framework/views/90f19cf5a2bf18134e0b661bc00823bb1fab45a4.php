
<?php $__env->startSection('breadcrumbs'); ?>
<h2 class="content-header-title float-left mb-0">Shop</h2>
<div class="breadcrumb-wrapper">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="index.html">Home</a>
        </li>
        <li class="breadcrumb-item"><a href="#">eCommerce</a>
        </li>
        <li class="breadcrumb-item active">Shop
        </li>
    </ol>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('searchBar'); ?>
<section id="ecommerce-searchbar" class="ecommerce-searchbar">
    <div class="row mt-1">
        <div class="col-sm-12">
            <form method="GET" action="<?php echo e(route('products.search')); ?>">
                <?php echo csrf_field(); ?>
            <div class="input-group input-group-merge">
                <input type="search" class="form-control search-product" name="query" id="shop-search" placeholder="Search Product" aria-label="Search..." aria-describedby="shop-search" />
                <div class="input-group-append">
                    <span class="input-group-text"><i data-feather="search" class="text-muted"></i></span>
                </div>
            </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- E-commerce Products Starts -->
<section id="ecommerce-products" class="grid-view">
    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="card ecommerce-card">
        <div class="item-img text-center">
            <a href="<?php echo e(route('products.show',$product)); ?>">
                <img class="img-fluid card-img-top" src="<?php echo e($product->image); ?>" alt="img-placeholder" />
            </a>
        </div>
        <div class="card-body">
            <div class="item-wrapper">
                <div>
                    <h6 class="item-price"><?php echo e($product->price); ?> DH</h6>
                </div>
                <div class="item-price text-danger">
                    <strike><?php echo e($product->old_price); ?> DH</strike>
                </div>
            </div>
            <h6 class="item-name">
                <a class="text-body" href="<?php echo e(route('products.show',$product)); ?>"><?php echo e($product->title); ?> </a>
            </h6>
            <p class="card-text item-description">
                <?php echo e($product->description); ?>

            </p>
        </div>
        
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p>There is no such Item !</p>
    <?php endif; ?>
    
</section>
<!-- E-commerce Products Ends -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sideBar'); ?>
<div class="sidebar-detached sidebar-left">
    <div class="sidebar">
        <!-- Ecommerce Sidebar Starts -->
        <div class="sidebar-shop">
            <div class="row">
                <div class="col-sm-12">
                    <h6 class="filter-heading d-none d-lg-block">Filters</h6>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <!-- Price Filter starts -->
                    <div class="multi-range-price">
                        <h6 class="filter-title mt-0">Multi Range</h6>
                        <ul class="list-unstyled price-range" id="price-range">
                            <li>
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="priceAll" name="price-range" class="custom-control-input" checked />
                                    <label class="custom-control-label" for="priceAll">All</label>
                                </div>
                            </li>
                            <li>
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="priceRange1" name="price-range" class="custom-control-input" />
                                    <label class="custom-control-label" for="priceRange1">&lt;=$10</label>
                                </div>
                            </li>
                            <li>
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="priceRange2" name="price-range" class="custom-control-input" />
                                    <label class="custom-control-label" for="priceRange2">$10 - $100</label>
                                </div>
                            </li>
                            <li>
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="priceARange3" name="price-range" class="custom-control-input" />
                                    <label class="custom-control-label" for="priceARange3">$100 - $500</label>
                                </div>
                            </li>
                            <li>
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="priceRange4" name="price-range" class="custom-control-input" />
                                    <label class="custom-control-label" for="priceRange4">&gt;= $500</label>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <!-- Price Filter ends -->

                    <!-- Categories Starts -->
                    <div id="product-categories">
                        <h6 class="filter-title">Categories</h6>
                        <ul class="list-group list-group-flush active">
                            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li class="list-group-item">    
                                <a class="list-group list-group-flush-action" href="<?php echo e(route('category.products',$category->slug)); ?>">
                                    <?php echo e($category->title); ?> 
                                    <?php echo e($category->products->count()); ?> 
                                </a>
                            </li>      
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li class="list-group-item">
                                No such Items !
                            </li> 
                            <?php endif; ?>
                        </ul>
                    </div>
                    <!-- Categories Ends -->

                    <!-- Brands starts -->

                    <!-- Brand ends -->

                    <!-- Rating starts -->

                    <!-- Rating ends -->

                    <!-- Clear Filters Starts -->
                    
                    <!-- Clear Filters Ends -->
                </div>
            </div>
        </div>
        <!-- Ecommerce Sidebar Ends -->

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Interface.eshop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce-website\resources\views/home.blade.php ENDPATH**/ ?>